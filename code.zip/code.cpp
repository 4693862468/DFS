
#include <bits/stdc++.h>
#include<chrono>
using namespace std;
using namespace std::chrono;
void printPath(vector<int> stack)
{
    int i;
    for (i = 0; i < (int)stack.size() - 1;
         i++) {
        cout << stack[i] << ">";
    }
    cout << stack[i];
}
void addEdge(vector<int> v[], int x,int y)
{
    v[x].push_back(y);
    v[y].push_back(x);
}
void DFSCall(int x, int y, vector<int> v[], int n, vector<int> stack)
{
    bool visited[n + 1];
 
    memset(visited, false, sizeof(vis));
    DFS(v, visited, x, y, stack);
}
 
void DFS(vector<int> v[], bool visited[], int x, int y,vector<int> stack)
{
    stack.push_back(x);
    if (x == y) {
        printPath(stack);
        return;
    }
    visited[x] = true;
    if (!v[x].empty()) {
        for (int j = 0; j < v[x].size(); j++) {
            if (visited[v[x][j]] == false)
                DFS(v, visited, v[x][j], y, stack);
        }
    }
 
    stack.pop_back();
}

int main()
{
    int n = 5;
    vector<int> v[n], stack;
 
    // vertex can only be upto 9 and not 0.
    addEdge(v, 0, 1);
    addEdge(v, 1, 2);
    addEdge(v, 2, 3);
    addEdge(v, 1, 4);
    auto start = high_resolution_clock::now();
    DFSCall(0, 4, v, n, stack);
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
  
    cout << "Time taken by function: "
         << duration.count() << " microseconds" << endl;
 
    return 0;
} 
