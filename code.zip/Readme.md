# DFS
This is the code to provide the time taken to run the the dfs algorithm on any given dataaset